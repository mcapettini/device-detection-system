/*
	Author:			Marco Capettini
	Content:		SOCKET PART
					Server that collects data from all ESPs and provides them to upper layers

	Team members:	Matteo Fornero, Fabio Carf�, Marco Capettini, Nicol� Chiapello
 */

#pragma once

#undef UNICODE

#define WIN32_LEAN_AND_MEAN // To speed the build process: reduce the size of the Win32 header files

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h> // To use functionalities of Winsock2
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <thread>
#include <vector>

#include "ESPpacket.h"
#include "Detection.h"
#include "BlockingQueue_Aggregator.h"
#include "PR_FrameIDs.h"

#pragma comment (lib, "Ws2_32.lib") // Better than manually include the library in linker's input dependecies

#define DEFAULT_BUFLEN 68 // Size of one single serialized packet (received)
#define DEFAULT_PORT "1500" // Server port

using namespace std;

class Socket
{
protected:

	// ATTRIBUTES
	int N_ESP; // Number of ESPs
	shared_ptr<BlockingQueue_Aggregator> BQ_A_ptr; // Pointer to the Blocking Queue of the Aggregator
	vector<SOCKET> s; // Vector of sockets used by threads to comunicate with ESPs
	bool localMacClock = false; // If true call manageLocalMac()

public:
	// CONSTRUCTOR
	Socket(int N_ESP, shared_ptr<BlockingQueue_Aggregator> BQ_A_ptr);

	// FUNCTIONAL OBJECT
	void operator() ();

	// OTHER METHODS
	/*
		Entry point of the server, the very start of all the system.
	
		"__cdecl" is a calling convenction: when you call a function, what happens at the assembly level is all the passed-in parameters are pushed to the stack,
		then the program jumps to a different area of code. The new area of code looks at the stack and expects the parameters to be placed there.
		Different calling conventions push parameters in different ways. "__cdecl" is the default calling convention for C and C++ programs.
		It permits to create larger executables than "__stdcall", because it requires each function call to include stack cleanup code.
	*/
	int __cdecl startServer();

	/*
		First step in synchronizing ESP with the server.
		The synchronization is done the first time an ESP connect to the server and also periodically every minute:
		more precisely every ESP, after having sent all the data of a "sniffing", re-synchronize it self with the server.
		In particular this function exchange a timestamp with ESP again and again in order to estimate the propagation time through wi-fi of those bytes
		then return the actual time + (propagation time / 2).
	*/
	chrono::milliseconds synch(SOCKET s);

	/*
		This is the function used to receive data from ESP. Receives and deserializes every single packet, and finally call the function putInBQ.
		This function is executed in parallel by different threads, in order to receive data from different ESPs at the same time.
	*/
	void recAndPut(SOCKET ListenSocket, int index, char* macBoard);

	/*	
		Simply convert packets from "ESPpacket" to "Detection" objects and put the into the Blockin Queue.
	*/
	void putInBQ(ESPpacket pkt, string macBoard);

	/*
		Each thread puts every received packet into the (same) Blocking Queue (which therefore will contain packets with local MAC and normal packets),
		The BQ will pass through Aggregator and Interpolator and finally the data will be uploaded into the DB.
		Every now and then (2 minutes) the server will call this function.
		It performs a SELECT on DB to retrieve local packets of the last 5 minutes, it tries to find correlations and finally UPDATEs the DB with new informations.
	*/
	//void manageLocalMac();

	static unsigned int parser(unsigned char *buffer, size_t len);
};