/*  Socket - local MAC recognizer
Team members: Matteo Fornero, Fabio Carf�, Marco Capettini, Nicol� Chiapello
Author: Marco Capettini */

#pragma once

#include "stdafx.h"
//#include <list>
#include <vector>
#include <iostream>
#include <sstream>
#include <bitset>
#include <string>
#include <chrono>
#include <ctime>
#include "Position.h"

class LocalMac
{
public:
	static void manageLocalMac();
};