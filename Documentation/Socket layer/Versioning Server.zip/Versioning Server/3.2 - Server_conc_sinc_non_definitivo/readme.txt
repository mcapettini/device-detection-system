da aggiungere:
-aggiustare il bug del 23
-inserimento in BQ (conversione da Packet a Detection)