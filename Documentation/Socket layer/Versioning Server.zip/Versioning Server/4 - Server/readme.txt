aggiunto:
-aggiustato il bug del 23 (sleep sull'ESP prima di chiudere la socket)

da aggiungere:
-inserimento in BQ (e precedente conversione da Packet a Detection)
-trasformare il codice in Socket.h e Socket.cpp, e in un oggetto funzionale (dotato di operator()),
 con parametri passati nel costruttore della classe, cos� operator() non li riceve quando invocato
-i parametri sono N_ESP e un riferimento (shared_ptr) alla BlockingQueue_Aggregator
-il segnale di stop � comunicato settando ad "alt" la variabile "_status" (enum) di Syncronizer.h
-testare concorrenza
-timeout recv?

da aggiungere con Matte:
-sostituire sleep con qualcosa di furbo (esp manda il numero di pacchetti che mander� cos� server poi manda messaggio end)
-(lato schedina) decidere che numero mettere come dimensione finestra TCP (non capisco come interpretate dati heap):
 SND_BUF = 5744
 start: 234456 | end: 234712
 start: 234848 | end: 234212
 start: 234560 | end: 234196
 start: 234384 | end: 233852
 SND_BUF = 11488
 start: 234456 | end: 234356
 start: 234696 | end: 234168
 start: 234496 | end: 234188
 start: 234188 | end: 233700
 start: 234028 | end: 233836
-timestamp
-hash