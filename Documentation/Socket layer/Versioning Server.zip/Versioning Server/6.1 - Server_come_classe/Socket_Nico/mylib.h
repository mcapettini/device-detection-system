#pragma once

/*  ESP32 Probe Request Analyzer
Team members: Matteo Fornero, Fabio Carf�, Marco Capettini, Nicol� Chiapello
Author: Fornero Matteo */

#include <string>
using namespace std;

/****************************************************************/

class ESPpacket
{
private:
	string MAC_address;
	string SSID;
	int RSSI;
	uint64_t timestamp;
	unsigned int seq_number;
	unsigned int hash_code;
public:
	ESPpacket();
	ESPpacket(string, string, int, uint64_t, unsigned int, unsigned int);
	~ESPpacket();
	string get_MAC();
	string get_SSID();
	uint64_t get_timestamp();
	unsigned int get_seqnum();
	unsigned int get_hash();
	int get_RSSI();
};

/****************************************************************/

#define SECONDS 1000 // convert microseconds to seconds
#define MAC_DIM 18
#define SSID_DIM 33

/****************************************************************/

ESPpacket deserialize_data(char *buffer);
unsigned int deserialize_uint(unsigned char *buffer);
uint64_t deserialize_lluint(unsigned char *buffer);