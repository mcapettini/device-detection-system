#include "pch.h"
#include "Socket.h"

int main(void) {
	shared_ptr<BlockingQueue_Aggregator> BQ_A_ptr = make_shared<BlockingQueue_Aggregator>(1);
	Socket socket(1, BQ_A_ptr);
	socket();

	return 0;
}