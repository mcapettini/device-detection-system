/*  ESP32 Probe Request Analyzer
Team members: Matteo Fornero, Fabio Carf�, Marco Capettini, Nicol� Chiapello
Author: Fornero Matteo */

#include "pch.h"
#include "mylib.h"

ESPpacket::ESPpacket()
{
	MAC_address = "";
	SSID = "";
	RSSI = 0;
	timestamp = 0;
	seq_number = 0;
	hash_code = 0;
}

ESPpacket::ESPpacket(string address, string ssid, int rssi, uint64_t time, unsigned int sequence, unsigned int hashval)
{
	MAC_address = address;
	SSID = ssid;
	RSSI = rssi;
	timestamp = time;
	seq_number = sequence;
	hash_code = hashval;
}

ESPpacket::~ESPpacket()
{
}

string ESPpacket::get_MAC()
{
	return MAC_address;
}

string ESPpacket::get_SSID()
{
	return SSID;
}

uint64_t ESPpacket::get_timestamp()
{
	return timestamp;
}

unsigned int ESPpacket::get_seqnum()
{
	return seq_number;
}

unsigned int ESPpacket::get_hash()
{
	return hash_code;
}

int ESPpacket::get_RSSI()
{
	return RSSI;
}

/*********************************************************/

ESPpacket deserialize_data(char *buffer)
{
	string _source(buffer, MAC_DIM);
	buffer += MAC_DIM;
	string _ssid(buffer, SSID_DIM);
	buffer += SSID_DIM;
	int _rssi = (int)buffer[0];
	buffer++;
	uint64_t _timestamp = deserialize_lluint((unsigned char*)buffer);
	buffer += 8;
	unsigned int _seq_num = deserialize_uint((unsigned char*)buffer);
	buffer += 4;
	unsigned int _hash = deserialize_uint((unsigned char*)buffer);
	ESPpacket pkt(_source, _ssid, _rssi, _timestamp, _seq_num, _hash);
	return pkt;
}

unsigned int deserialize_uint(unsigned char *buffer)
{
	unsigned int value = 0;
	value = buffer[0];
	value = value << 8;
	value += buffer[1];
	value = value << 8;
	value += buffer[2];
	value = value << 8;
	value += buffer[3];
	return value;
}

uint64_t deserialize_lluint(unsigned char *buffer)
{
	uint64_t value = 0;
	value = buffer[0];
	value = value << 8;
	value += buffer[1];
	value = value << 8;
	value += buffer[2];
	value = value << 8;
	value += buffer[3];
	value = value << 8;
	value += buffer[4];
	value = value << 8;
	value += buffer[5];
	value = value << 8;
	value += buffer[6];
	value = value << 8;
	value += buffer[7];
	return value;
}