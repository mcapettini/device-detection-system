/* Socket part: provide a server to collect data from ESPs and bring them to upper layers
Team members: Matteo Fornero, Fabio Carf�, Marco Capettini, Nicol� Chiapello
Author: Marco Capettini */

#pragma once

#undef UNICODE

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include "mylib.h"
#include <thread>
#include <mutex>
#include <vector>

#include "Detection.h"
#include "BlockingQueue_Aggregator.h"

#pragma comment (lib, "Ws2_32.lib")
// #pragma comment (lib, "Mswsock.lib")

#define DEFAULT_BUFLEN 68
#define DEFAULT_PORT "1500"

using namespace std;

class Socket
{
//Attributes
protected:
	int N_ESP;
	shared_ptr<BlockingQueue_Aggregator> BQ_A_ptr;

//Methods
public:
	//Constructor
	//Socket(int N_ESP, shared_ptr<BlockingQueue_Aggregator> BQ);
	Socket(int N_ESP, shared_ptr<BlockingQueue_Aggregator> BQ_A_ptr);

	//Functional object
	void operator() ();

	//Other methods
	int __cdecl startServer();

	chrono::milliseconds synch(SOCKET s);
	
	void recAndPut(SOCKET ListenSocket, chrono::milliseconds syncTimestamp, SOCKET syncSkt);
	
	void putInBQ(ESPpacket pkt, string macBoard);

	void serialize_lluint(unsigned char *buffer, uint64_t value);
};