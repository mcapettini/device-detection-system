IMPORTANTE:
ricordarsi di cambiare parametro dimensione finestra TCP lwIP SND_BUF = 11488 o pi�

aggiunto:
-esp manda il numero di pacchetti che mander� cos� server poi manda messaggio end
-timestamp/sincronizzazione funzionante

da aggiungere/testare:
-vedere se l'hash funziona con la concorrenza e testarla
-inserimento in BQ (e precedente conversione da Packet a Detection)
-trasformare il codice in Socket.h e Socket.cpp, e in un oggetto funzionale (dotato di operator()),
 con parametri passati nel costruttore della classe, cos� operator() non li riceve quando invocato
-i parametri sono N_ESP e un riferimento (shared_ptr) alla BlockingQueue_Aggregator
-il segnale di stop � comunicato settando ad "alt" la variabile "_status" (enum) di Syncronizer.h
-timeout recv?