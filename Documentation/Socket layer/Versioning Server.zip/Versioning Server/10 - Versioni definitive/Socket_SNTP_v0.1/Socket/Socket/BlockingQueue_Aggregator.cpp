// ~-----libraries-----------------------------------------------------------------------------------------------------------------------------------------------------
//#include "stdafx.h"
#include "pch.h"
#include "BlockingQueue_Aggregator.h"


// ~-----namespaces----------------------------------------------------------------------------------------------------------------------------------------------------
using namespace std;



// ~-----constructors and destructors----------------------------------------------------------------------------------------------------------------------------------
BlockingQueue_Aggregator::BlockingQueue_Aggregator(int number_boards) : _number_boards(number_boards)
{
}



// ~-----methods-------------------------------------------------------------------------------------------------------------------------------------------------------

/* Nicol�:
 * this method adds a Detection object to the BlockingQueue
 * used by Socket to submit data
 */
void BlockingQueue_Aggregator::insert(Detection detection) {
	// ~-----local variables------------------------------------------------
	unique_lock<mutex> ul(_m);

	// ~-----insert in the blocking queue-----------------------------------
	_queue.push_back(detection);

	// ~-----wake up all the waiting Aggregators----------------------------
	_cv.notify_all();
}


/* Nicol�:
 * this method gets N Detection objects from the BlockingQueue, one for each board
 * used by Aggregator to retrieve data
 */
std::vector<Detection> BlockingQueue_Aggregator::retrieve() {
	// ~-----local variables------------------------------------------------
	unique_lock<mutex> ul(_m);
	vector<Detection> output_list;
	int seconds = 31;

	// ~-----loop until receives stop signal from external environment------
	while (true) {	//TODO: define a stop signal from C#

		// ~-----scan all the BlockingQueue looking for matches-------------
		output_list.clear();
		if (count_occurences(output_list))
			return output_list;

		// ~-----no matches found, so sleep---------------------------------
		chrono::seconds sec(seconds);	//TODO: discuss the better value for waiting time
		cv_status wakeup_reason;
		wakeup_reason = _cv.wait_for(ul, sec);

		// ~-----woke up by an insertion------------------------------------
		if (wakeup_reason == cv_status::no_timeout) {
			continue;
		}

		// ~-----woke up by timeout expiring--------------------------------
		else if (wakeup_reason == cv_status::timeout) {
			_queue.clear();
		}
	}

	// ~-----return code for receiving stop signal from external environment--
	return {};
}


/* Nicol�:
 * this method returns all the found Detection objects, having the provided hash value
 */
bool BlockingQueue_Aggregator::has_enough_detections(int hash_desired) {
	// ~-----local variables------------------------------------------------
	int count = 0;
	deque<Detection>::iterator iterator = _queue.begin();

	// ~-----count the occurences of 'hash desired'-------------------------
	for (; iterator != _queue.end(); iterator++) {
		if (iterator->hash() == hash_desired)
			count++;
	}

	// ~-----check if the occurences are enough-----------------------------
	if (count > _number_boards)
		throw new exception("Too many Detection with the same hash number");	//TODO: better handle this situation
	else if (count == _number_boards)
		return true;
	else
		return false;
}


/* Nicol�:
 * this method rip off the Detection objects having the provided hash value
 */
std::vector<Detection> BlockingQueue_Aggregator::extract(int hash_desired) {
	// ~-----local variables------------------------------------------------
	vector<Detection> list_output;
	deque<Detection>::iterator iterator = _queue.begin();

	// ~-----retrieve the occurences of 'hash desired'----------------------
	for (; iterator != _queue.end(); iterator++) {
		if (iterator->hash() == hash_desired) {
			// insert in the new list
			list_output.push_back(*iterator);
			// delete from the old queue
			_queue.erase(iterator);	//TODO: check if the iterator doesn't jump some elements due to erasing
		}
	}

	// ~-----return the filled list-----------------------------------------
	return list_output;
}


/* Nicol�:
 * this method count the occurrences of the Detection objects and eventually return (as parameter)
 * the list of first N occurences found
 */
bool BlockingQueue_Aggregator::count_occurences(std::vector<Detection> &element) {
	// ~-----local variables------------------------------------------------
	map<int, set<Detection>> map_occurences;

	// ~-----count the occurences of each hash------------------------------
	for (auto iterator = _queue.begin(); iterator != _queue.end(); iterator++) {

		// ~-----new hash---------------------------------------------------
		if (map_occurences.find(iterator->hash()) == map_occurences.end()) {
			set<Detection> internal_set;
			internal_set.insert(*iterator);
			map_occurences.insert(make_pair(iterator->hash(), internal_set));
		}

		// ~-----hash already present---------------------------------------
		else {
			// retrieve the map element
			map<int, set<Detection>>::iterator map_iterator = map_occurences.find(iterator->hash());

			// add the new Detection to the set (can cause exception)
			map_iterator->second.insert(*iterator);

			// check if is reached the number of boards
			if (map_iterator->second.size() == _number_boards) {
				copy(map_iterator->second.begin(), map_iterator->second.end(), back_inserter(element));

				for (auto set_iterator = map_iterator->second.begin(); set_iterator != map_iterator->second.end(); set_iterator++) {
					auto target = find(_queue.begin(), _queue.end(), *set_iterator);
					_queue.erase(target);
				}

				return true;
			}

		}
	}

	// ~-----return code for failure-----------------------------------------
	return false;
}


// ~-----getters and setters---------------------------------------------------------------------------------------------------------------------------------------