#pragma once

// ~-----libraries-----------------------------------------------------------------------------------------------------------------------------------------------------
//#include "stdafx.h"
#include "Detection.h"
#include <deque>
#include <mutex>
#include <vector>
#include <map>
#include <set>


// ~-----class---------------------------------------------------------------------------------------------------------------------------------------------------------

/* Nicol�:
 * collection of data, in Detection object format, handled in thread-safe mode
 * used by Socket to provide data to the Aggregator
 */
class BlockingQueue_Aggregator
{
protected:
	// ~-----attributes------------------------------------------------------------------------------------------------------------------------------------------------
	int						_number_boards;
	std::deque<Detection>	_queue;
	std::mutex				_m;
	std::condition_variable _cv;



public:
	// ~-----constructors and destructors------------------------------------------------------------------------------------------------------------------------------
	BlockingQueue_Aggregator(int number_boards);



	// ~-----methods-------------------------------------------------------------------------------------------------------------------------------------------------------

	/* Nicol�:
	 * this method adds a Detection object to the BlockingQueue
	 * used by Socket to submit data
	 */
	void insert(Detection detection);

	/* Nicol�:
	 * this method gets N Detection objects from the BlockingQueue, one for each board
	 * used by Aggregator to retrieve data
	 */
	std::vector<Detection> retrieve();


private:
	/* Nicol�:
	 * this method returns all the found Detection objects, having the provided hash value
	 */
	bool has_enough_detections(int hash_desired);

	/* Nicol�:
	 * this method rip off the Detection objects having the provided hash value
	 */
	std::vector<Detection> extract(int hash_desired);


	/* Nicol�:
	 * this method count the occurrences of the Detection objects and return (as parameter)
	 * the list of first N occurences found
	 */
	bool count_occurences(std::vector<Detection> &element);


	// ~-----getters and setters---------------------------------------------------------------------------------------------------------------------------------------

};

