/*
Author:			Marco Capettini
Content:		Main used for testing the server while not having upper layers.
				After joining the code, this part can be neglected.

Team members:	Matteo Fornero, Fabio Carf�, Marco Capettini, Nicol� Chiapello
 */

#include "pch.h"
#include "Socket.h"

int main(void) {
	shared_ptr<BlockingQueue_Aggregator> BQ_A_ptr = make_shared<BlockingQueue_Aggregator>(1);
	Socket socket(2, BQ_A_ptr);
	socket();

	return 0;
}