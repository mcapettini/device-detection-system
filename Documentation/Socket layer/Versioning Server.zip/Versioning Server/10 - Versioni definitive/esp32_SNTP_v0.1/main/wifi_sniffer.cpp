//	ESP32 Probe Request Analyzer
//	Team members: Matteo Fornero, Fabio Carfì, Marco Capettini, Nicolò Chiapello
//	Author: Fornero Matteo 

#include "cppheader.hpp"
using namespace std;

// for details about the wifi_event_group and the bits see comments in main.c
extern EventGroupHandle_t wifi_event_group;
extern const int CONNECTED_BIT;
extern const int RECONNECT_BIT;
extern const int TIME_BIT;

extern const char* TAG; // tag for esp_log_events API
extern char esp_mac[MAC_DIM]; // global because of initialization on main function

// unordered_map<string, unsigned int> pkt_map; // unordered map to store source and timestamp of received packets in order to filter them (so we use less memory and we send less data through the network)
list<packet> pkt_list; // list to store data structures containing all important details about received packets
// WARNING: both map and list must be global variables because they must be accessed/modified in the callback function which only allows 2 parameters by design of Espressif

uint8_t channel = 1; // first channel to be scanned
int curr_socket = -1;
struct timeval tv;
uint64_t epoch = 0;

// necessary for C++ compatibility
extern "C" {
	void wifi_sniffer();
}

/* This function handles the real job that has to be done by the ESP32, notice that there is a neverending loop inside it because we want our system
   to be always active. In a real-world scenario this could be a problem if we use batteries to power-up the system, a possible solution could be to use
   the local time (ex. from SNTP server) to determine the moments when the system can be inactive (ex. from 8PM to 7AM in case of a university room), so
   in those moments we yield the resources to a low priority task that does nothing and just waits the right moment to wake up the system (soft of simple
   power saving mode).
*/
void wifi_sniffer()
{
	ESP_ERROR_CHECK(esp_wifi_start()); // start wifi
	size_t freeheap = 0; // debug only - to be removed
	for(;;){ // infinite loop
		freeheap = xPortGetFreeHeapSize(); // debug only - to be removed	
		xEventGroupSetBits(wifi_event_group, RECONNECT_BIT); // reconnect in case of disconnection
		ESP_ERROR_CHECK(esp_wifi_connect()); // connect to the AP
		xEventGroupWaitBits(wifi_event_group, CONNECTED_BIT, pdFALSE, pdTRUE, portMAX_DELAY); // wait forever until connection to the AP is ok	
		NTPsynch(); // get time from SNTP server
		while(synch() == false){}; // keep synching until we succeed
		xEventGroupClearBits(wifi_event_group, RECONNECT_BIT); // do not reconnect in case of disconnection
		ESP_ERROR_CHECK(esp_wifi_disconnect()); // disconnect from wifi, otherwise packet capture would be done on the channel of the AP
		tracking(channel); // this function handles the packet capture
		xEventGroupSetBits(wifi_event_group, RECONNECT_BIT); // reconnect in case of disconnection
		ESP_ERROR_CHECK(esp_wifi_connect()); // reconnect to wifi
		xEventGroupWaitBits(wifi_event_group, CONNECTED_BIT, pdFALSE, pdTRUE, portMAX_DELAY); // wait forever until connection (maybe not forever and if not connected we skip everything and jump to new synch?)
		send_data(); // send data to computer
		pkt_list.clear(); // free space used for list
		channel = (channel % CHANNELS) + 1; // go on with next channel	
		ESP_LOGI(TAG, "HEAP MEMORY STATS -> start: %u | end: %u", freeheap, xPortGetFreeHeapSize()); // debug only - to be removed
	}	
}

void NTPsynch()
{
	char buffer[100];
	ip_addr_t addr;
	inet_pton(AF_INET, "192.168.1.2", &addr);
	// initialize the SNTP service
	sntp_setoperatingmode(SNTP_OPMODE_POLL);
	sntp_setserver(0, &addr);
	sntp_init();
	// wait for the service to set the time
	time_t now;
	struct tm timeinfo;
	time(&now);
	localtime_r(&now, &timeinfo);
	while(timeinfo.tm_year < (2018 - 1900)) {
		printf("Time not set, waiting...\n");
		vTaskDelay(5000 / portTICK_PERIOD_MS);
		time(&now);
        localtime_r(&now, &timeinfo);
	}
	// change the timezone to Italy
	setenv("TZ", "CET-1CEST-2,M3.5.0/02:00:00,M10.5.0/03:00:00", 1);
	tzset();
	// print the actual time in Italy
	printf("Actual time in Italy:\n");
	localtime_r(&now, &timeinfo);
	strftime(buffer, sizeof(buffer), "%d/%m/%Y %H:%M:%S", &timeinfo);
	printf("%s\n", buffer);
	// print epoch time
	if(gettimeofday(&tv, NULL)!=0){
		ESP_LOGE(TAG, "Error on gettimeofday()");
	} else {
		epoch = ((uint64_t)tv.tv_sec*1000)+((uint64_t)tv.tv_usec/1000);
		ESP_LOGI(TAG, "Seconds: %ld | Microseconds: %ld | Epoch: %llu", tv.tv_sec, tv.tv_usec, epoch);
	}
	sntp_stop();
}

// enable sniffer, wait 60 seconds, disable sniffer (in this time interval each probe request packet triggers the callback function)
void tracking(uint8_t channel)
{
	ESP_LOGI(TAG, "starting to monitor probe requests on channel %u...", channel);
	ESP_ERROR_CHECK(esp_wifi_set_promiscuous_rx_cb(&cb_func)); // register the callback function
	wifi_promiscuous_filter_t filter; // packet sniffing filters and parameters
	filter.filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT; // filter management packets (probe req. are among them)
	ESP_ERROR_CHECK(esp_wifi_set_promiscuous_filter(&filter)); // set the filter
	ESP_ERROR_CHECK(esp_wifi_set_channel(channel, WIFI_SECOND_CHAN_NONE)); // set channel to be scanned, do not use a second channel
	ESP_ERROR_CHECK(esp_wifi_set_promiscuous(true)); // set the wifi interface into promiscuous mode
	vTaskDelay(SCAN_INTERVAL / portTICK_PERIOD_MS); 
	ESP_ERROR_CHECK(esp_wifi_set_promiscuous(false)); // disable promiscuous mode
	ESP_LOGI(TAG, "probe request monitoring completed, collected %d packets.", pkt_list.size());
	//pkt_map.clear(); // free space used for map because it is no longer needed
}

// callback function for probe request packets
void cb_func(void *buf, wifi_promiscuous_pkt_type_t type)
{
	// get epoch time
	if(gettimeofday(&tv, NULL)!=0){
		ESP_LOGE(TAG, "Error on gettimeofday()");
	} else {
		epoch = ((uint64_t)tv.tv_sec*1000)+((uint64_t)tv.tv_usec/1000);
	}
	
	if(type != WIFI_PKT_MGMT){
		return; // if not a management packet return (should not be necessary if the filter works correctly)
	}

	// collect some informations about the captured packet (automatically given by the callback implementation, no need to look inside the packet at this step)
	const wifi_promiscuous_pkt_t *capt_pkt = (wifi_promiscuous_pkt_t *)buf; // API specific
	int8_t rssi = capt_pkt->rx_ctrl.rssi;
	unsigned int pkt_len = capt_pkt->rx_ctrl.sig_len; // length of packet including Frame Check Sequence (FCS) 
	unsigned int channel = capt_pkt->rx_ctrl.channel;
	unsigned int isHT40 = capt_pkt->rx_ctrl.cwb; // 0: "standard" frame header - 1: "extended" HT frame header
	//unsigned int timestamp = capt_pkt->rx_ctrl.timestamp;
	
	// the MAC header structure of the captured packet depends on the 802.11 standard that has been used (b/g/n) so we must adopt different strategies
	// to read correctly the informations inside the MAC header and inside the payload (the variable isHT40 is used for this purpose)
	const payload_t *payload = NULL;
	size_t payload_size = 0;
	unsigned int pkt_type = 0;
	unsigned int pkt_subtype = 0;
	unsigned int seq_num = 0;
	char tmp[MAC_DIM]; // temporary buffer to store source MAC address
	string source_mac;
	string ssid;

	// case 1 -> 802.11 non-HT (24 bytes for the header, 0-2312 byte for the frame body, 4 bytes for FCS)
	if(isHT40 == 0){
		const packet_t *packet = (packet_t*)capt_pkt->payload; // packet is a pointer to an area of memory that is treated as a "packet structure"
		payload_size = (size_t)pkt_len - MINHEADER; // this is the effective size of the payload of the captured packet (total size - header - fcs)
		const mac_header_t *header = &packet->header; // this is the MAC header of the captured packet
		pkt_type = header->type; // type of the packet (should be 00 -> management)
		pkt_subtype = header->subtype; // subtype of the packet (should be 0100 -> probe request)
		payload = &packet->payload; // this is the payload of the captuerd packet
		seq_num = header->seq_ctrl;
		sprintf(tmp, "%02x:%02x:%02x:%02x:%02x:%02x", header->source_addr[0], header->source_addr[1], header->source_addr[2], header->source_addr[3], header->source_addr[4], header->source_addr[5]);
		source_mac.assign(tmp);
	}

	// case 2 -> 802.11 HT mode (28 bytes for the header, 0-2312 byte for the frame body, 4 bytes for FCS)
	if(isHT40 == 1){
		const packet_HT40_t *packet = (packet_HT40_t*)capt_pkt->payload; 
		payload_size = (size_t)pkt_len - MAXHEADER; 
		const mac_header_HT40_t *header = &packet->header; 
		pkt_type = header->type; 
		pkt_subtype = header->subtype; 
		payload = &packet->payload;
		seq_num = header->seq_ctrl;
		sprintf(tmp, "%02x:%02x:%02x:%02x:%02x:%02x", header->source_addr[0], header->source_addr[1], header->source_addr[2], header->source_addr[3], header->source_addr[4], header->source_addr[5]);
		source_mac.assign(tmp);
	}

	if(pkt_type!=0 || pkt_subtype!=4){
		return; // at this point we read into the MAC header the type and subtype of the packet. if it is not a probe request packet return.
	}
	
	//ESP_LOGI(TAG, "Current epoch time is: %llu | Timestamp value is: %d", epoch, timestamp);

	// now we can look into the payload to collect the last information we need: the SSID that the device is searching (ssid could be empty, do this only if payload is not empty)
	if( (payload_size > 0) && (payload->ssid_len > 0) ){
		ssid.assign(payload->ssid, payload->ssid_len);
		ssid.append(1, '\0'); // add null terminator
	} else {
		ssid.assign("broadcast\0");
	}
	
	// prepare data for hash
	hash<string> hs;
	string in_hash; 
	char tmp2[20]; 
	memset(tmp2, '0', 20);
	in_hash.assign(source_mac);
	in_hash.append(ssid);
	itoa(seq_num, tmp2, 10);
	in_hash.append(tmp2);
	size_t hashvalue = hs(in_hash); // compute hash of packet
	packet pkt(source_mac, ssid, rssi, epoch, seq_num, hashvalue); // create packet object 
	pkt_list.push_back(pkt); // insert packet into list of packets to be sent to the computer
	ESP_LOGI(TAG, "Source: %s | SSID: %s | Timestamp: %llu | Channel: %u | RSSI: %d | Seq.Numb: %u | Hash: %u", source_mac.c_str(), ssid.c_str(), epoch, channel, rssi, seq_num, hashvalue);
	
	/*unordered_map<string, unsigned int>::iterator it = pkt_map.find(source_mac); // check if source MAC is already in the map
	if (it != pkt_map.end() && ((CONV2MS(timestamp) - CONV2MS(it->second)) > 0)) { // MAC already in map and previous packet registered more than TIME_DIFF seconds ago
		it->second = timestamp; // update timestamp in map at key = source MAC
		packet pkt(source_mac, ssid, rssi, recv_time, seq_num, hashvalue); // create packet object 
		pkt_list.push_back(pkt); // insert packet into list of packets to be sent to the computer
		ESP_LOGI(TAG, "Source: %s | SSID: %s | Timestamp: %llu | Channel: %u | RSSI: %d | Seq.Numb: %u | Hash: %u", source_mac.c_str(), ssid.c_str(), recv_time, channel, rssi, seq_num, hashvalue);
	}
	if (it == pkt_map.end()) { // new MAC source address
		pair<string, unsigned int> element(source_mac, timestamp); // pair object that contains key and value for the map
		pkt_map.insert(element); // insert element into map
		packet pkt(source_mac, ssid, rssi, recv_time, seq_num, hashvalue);
		pkt_list.push_back(pkt);
		ESP_LOGI(TAG, "Source: %s | SSID: %s | Timestamp: %llu | Channel: %u | RSSI: %d | Seq.Numb: %u | Hash: %u", source_mac.c_str(), ssid.c_str(), recv_time, channel, rssi, seq_num, hashvalue);
	}*/
}

// this function simply establish a socket and a connection with the computer
int make_socket()
{
	struct sockaddr_in pc_addr;
	pc_addr.sin_family = AF_INET;
	pc_addr.sin_port = htons(PORT);
	int res = inet_pton(AF_INET, IP_ADDRESS, &(pc_addr.sin_addr));
	if(res <= 0){
		return -1;
	}
	int s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if(s < 0){
		return -1;
	}
	if(connect(s, (struct sockaddr*) &pc_addr, sizeof(pc_addr)) != 0){
		close(s);
		return -1;
	}
	return s;
}

// this function sends collected data to the access point
void send_data()
{
	curr_socket = make_socket();
	if(curr_socket < 0){
		ESP_LOGE(TAG, "send_data() - error creating socket");
		return;
	}
	ssize_t retvalue = 0; // to check the return value of send, write, read and recv
	uint32_t dim = pkt_list.size(); // number of packets collected by the ESP32 (with basic filters already applied)
	unsigned char pkt_num[4]; // we need 4 bytes because the number of packets is on 32 bit
	memset(pkt_num, '0', 4);
	serialize_uint(pkt_num, dim); // data serialization for transmission over socket
	retvalue = write(curr_socket, pkt_num, 4); // send total number of packets that are going to be sent
	if(retvalue != 4){
		close(curr_socket);
		ESP_LOGE(TAG, "send_data() - error sending # of packets to pc");
		return;
	}
	
	char *buffer = NULL;
	buffer = (char*)malloc(BUFDIM);
	if(buffer==NULL){
		close(curr_socket);
		ESP_LOGE(TAG, "send_data() - error allocating memory for tx buffer");
		return;
	}
	
	// now iterate through the list and send a packet for each element into the list (we pay a lot of overhead but we reduce risks of losing data during the transmission)
	for (list<packet>::iterator it = pkt_list.begin(); it != pkt_list.end(); it++) {
		memset(buffer, 0, BUFDIM); // clear the buffer
		serialize_data(*it, buffer); // put data inside the buffer
		ssize_t res = write(curr_socket, buffer, BUFDIM);
		if(res != BUFDIM){
			free(buffer);
			close(curr_socket);
			ESP_LOGE(TAG, "send_data() - error sending data to pc");
			return;
		}
	}
	free(buffer);
}

// this function performs the synchronization between a single ESP32 board and the PC used to collect and store data
bool synch()
{
	ssize_t retvalue = 0;
	char buffer[10];
	memset(buffer, '0', 10);
	struct timeval tv; 
	tv.tv_sec = 10;
	tv.tv_usec = 0;
	fd_set rdfd;
	
	bool sock_alive = false;
	if(curr_socket != -1){ // check if socket can be reused
		retvalue = write(curr_socket, "ALIVE\0", 6);
		if(retvalue==6){	
			FD_ZERO(&rdfd); FD_SET(curr_socket, &rdfd); 
			retvalue = select(curr_socket+1, &rdfd, NULL, NULL, &tv);
			if(retvalue==-1 || !FD_ISSET(curr_socket, &rdfd)){ // select error or timeout expired
				close(curr_socket);
			} else {
				retvalue = read(curr_socket, buffer, 6);
				if((retvalue==6) && (strncmp(buffer, "ALIVE\0", 6)==0)){
					sock_alive = true;
				}
			}		
		}
	}
	
	if(curr_socket==-1 || sock_alive==false){ // if channel is 1 we need to open a new socket (because previously we were disconnected from the AP)
		close(curr_socket); // close current socket (just to avoid leaving a dangling socket around...maybe this socket is not even a valid file descriptor anymore)
		curr_socket = make_socket();
		if(curr_socket < 0){
			ESP_LOGE(TAG, "synch() - error creating socket");
			return false;
		}
		ESP_LOGE(TAG, "synch() - new socket created");
	} else {
		ESP_LOGE(TAG, "synch() - old socket recovered");
	}
	
	retvalue = write(curr_socket, esp_mac, MAC_DIM); // send ESP32's MAC to computer
	if(retvalue != MAC_DIM){
		close(curr_socket);
		ESP_LOGE(TAG, "synch() - error sending MAC to PC");
		return false;
	}
	
	retvalue = read(curr_socket, buffer, 3); // now wait for the GO signal
	if(retvalue != 3 || strncmp(buffer, "GO\0", 3) != 0){
		close(curr_socket);
		channel++;
		ESP_LOGE(TAG, "synch() - error on GO signal");
		return false;
	}	
	close(curr_socket);
	return true;
}