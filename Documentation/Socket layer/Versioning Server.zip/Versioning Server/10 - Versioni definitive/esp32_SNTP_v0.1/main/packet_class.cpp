//	ESP32 Probe Request Analyzer
//	Team members: Matteo Fornero, Fabio Carfì, Marco Capettini, Nicolò Chiapello
//	Author: Fornero Matteo 

// this very simple code implements the methods of class packet

#include "cppheader.hpp"
using namespace std;

packet::packet()
{
	MAC_address = "";
	SSID = "";
	RSSI = 0;
	timestamp = 0;
	seq_number = 0;
	hash_code = 0;
}

packet::packet(string address, string ssid, int rssi, uint64_t time, unsigned int sequence, unsigned int hashval)
{
	MAC_address = address;
	SSID = ssid;
	RSSI = rssi;
	timestamp = time;
	seq_number = sequence;
	hash_code = hashval;
}

packet::~packet()
{
}

string packet::get_MAC()
{
	return MAC_address;
}

string packet::get_SSID()
{
	return SSID;
}

uint64_t packet::get_timestamp()
{
	return timestamp;
}

unsigned int packet::get_seqnum()
{
	return seq_number;
}

unsigned int packet::get_hash()
{
	return hash_code;
}

int packet::get_RSSI()
{
	return RSSI;
}