//	ESP32 Probe Request Analyzer
//	Team members: Matteo Fornero, Fabio Carfì, Marco Capettini, Nicolò Chiapello
//	Author: Fornero Matteo 							  									

#include "stdio.h"
#include "stdlib.h"
#include "string.h"

// ESP32 specific headers
#include "esp_wifi.h"
#include "esp_event_loop.h"
#include "freertos/event_groups.h"
#include "freertos/FreeRTOS.h"
#include "nvs_flash.h"
#include "lwip/sockets.h"
#include "esp_log.h"
#include "lwip/apps/sntp.h"

#define _SSID "AP4ESP32"
#define PASSWORD "11235813"

void mysys_init();
esp_err_t event_handler(void *ctx, system_event_t *event);