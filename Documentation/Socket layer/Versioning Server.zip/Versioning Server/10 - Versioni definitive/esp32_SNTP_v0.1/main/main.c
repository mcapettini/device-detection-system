//	ESP32 Probe Request Analyzer
//	Team members: Matteo Fornero, Fabio Carfì, Marco Capettini, Nicolò Chiapello
//	Author: Fornero Matteo 

#include "cheader.h"
const char* TAG = "message_by_developer"; // tag for ESP_LOGx function
extern void wifi_sniffer(); // this is the function that does the real job (C++, implementation is in ".cpp" sources)
EventGroupHandle_t wifi_event_group;
const int CONNECTED_BIT = BIT0;	
const int RECONNECT_BIT = BIT1; 
const int TIME_BIT = BIT2;

char esp_mac[18]; // global variable to store esp32 mac address

/***********************************************************************************************************************/

/* MAIN */ 
void app_main()
{
	wifi_event_group = xEventGroupCreate(); // group of bits for wifi events
	mysys_init(); // initialize system components and wifi
	wifi_sniffer(); // this is the function that handles the real "job" and that should never return
}

// system initialization function (one-time execution)
void mysys_init()
{
	uint8_t wint_mac[6];
	memset(wint_mac, '0', 6);
	memset(wint_mac, '0', 18);
	ESP_LOGI(TAG, "mysys_init() - starting system initialization...");
	ESP_ERROR_CHECK(nvs_flash_init()); // NVS (associative-like memory) initialization
	tcpip_adapter_init(); // tcp stack initialization
    ESP_ERROR_CHECK(esp_event_loop_init(event_handler, NULL)); // this is the event handler
    wifi_init_config_t myconf = WIFI_INIT_CONFIG_DEFAULT(); // default wifi stack configuration parameters
    ESP_ERROR_CHECK(esp_wifi_init(&myconf)); // wifi stack initialization function
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA)); // set the wifi interface to STA mode
    wifi_config_t wconf = { }; // be sure to set entire wifi_config_t variable to 0
    memcpy(&wconf.sta.ssid, _SSID, strlen(_SSID));
    memcpy(&wconf.sta.password , PASSWORD, strlen(PASSWORD));
	ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_STA, &wconf));
	esp_wifi_set_ps(WIFI_PS_NONE); 
	wifi_country_t wifi_country;
	strcpy(wifi_country.cc, "IT\0");
	wifi_country.schan = 1;
	wifi_country.nchan = 13;
	wifi_country.max_tx_power = 100;
	wifi_country.policy = WIFI_COUNTRY_POLICY_AUTO;
	ESP_ERROR_CHECK(esp_wifi_set_country(&wifi_country));
	ESP_ERROR_CHECK(esp_wifi_get_mac(ESP_IF_WIFI_STA, wint_mac));
	ESP_LOGI(TAG, "mysys_init() - AP set to: %s - Password set to: %s.", _SSID, PASSWORD);
    ESP_LOGI(TAG, "mysys_init() - system initialization completed.");
	sprintf(esp_mac, "%02x:%02x:%02x:%02x:%02x:%02x", wint_mac[0], wint_mac[1], wint_mac[2], wint_mac[3], wint_mac[4], wint_mac[5]);
}

// this function is the event handler that is called every time a new "event" is posted to the system
esp_err_t event_handler(void *ctx, system_event_t *event)
{
	//system_event_sta_disconnected_t *disconnected;
	EventBits_t uxBits;
	switch (event->event_id) {
		case SYSTEM_EVENT_AP_PROBEREQRECVED: // this is never triggered by default (may be deprecated in future releases of esp-idf)
			ESP_LOGI(TAG, "Detected SYSTEM_EVENT_AP_PROBEREQRECVED");
			break;
		case SYSTEM_EVENT_STA_GOT_IP: // this means the ESP32 has got an IP from the AP so esp_wifi_connect() was successfull
			ESP_LOGI(TAG, "Detected SYSTEM_EVENT_STA_GOT_IP");
			xEventGroupSetBits(wifi_event_group, CONNECTED_BIT);
			break;
		case SYSTEM_EVENT_STA_LOST_IP:
			ESP_LOGI(TAG, "Detected SYSTEM_EVENT_STA_LOST_IP");
			xEventGroupClearBits(wifi_event_group, CONNECTED_BIT);
			uxBits = xEventGroupWaitBits(wifi_event_group, RECONNECT_BIT, pdFALSE, pdTRUE, 0); 
			if((uxBits & RECONNECT_BIT) != 0){
				ESP_ERROR_CHECK(esp_wifi_connect());
			}
			break;
		case SYSTEM_EVENT_STA_CONNECTED:
			ESP_LOGI(TAG, "Detected SYSTEM_EVENT_STA_CONNECTED");
			break;
		case SYSTEM_EVENT_STA_DISCONNECTED:
			ESP_LOGI(TAG, "Detected SYSTEM_EVENT_STA_DISCONNECTED");
			xEventGroupClearBits(wifi_event_group, CONNECTED_BIT);
			//disconnected = &event->event_info.disconnected;
			//ESP_LOGE(TAG, "SSID: %s | SSID_len: %d | bssid: " MACSTR " | reason: %d", disconnected->ssid, disconnected->ssid_len, MAC2STR(disconnected->bssid), disconnected->reason);
			uxBits = xEventGroupWaitBits(wifi_event_group, RECONNECT_BIT, pdFALSE, pdTRUE, 0); 
			if((uxBits & RECONNECT_BIT) != 0){
				ESP_ERROR_CHECK(esp_wifi_connect());
			}
			break; 
		case SYSTEM_EVENT_STA_START:
			ESP_LOGI(TAG, "Detected SYSTEM_EVENT_STA_START");
			break;
		case SYSTEM_EVENT_STA_STOP:
			ESP_LOGI(TAG, "Detected SYSTEM_EVENT_STA_STOP");
			break;
		default: 
			break;
	}
    return ESP_OK;
}