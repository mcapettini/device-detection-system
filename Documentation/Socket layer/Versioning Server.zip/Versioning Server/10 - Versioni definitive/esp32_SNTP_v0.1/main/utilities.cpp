//	ESP32 Probe Request Analyzer
//	Team members: Matteo Fornero, Fabio Carfì, Marco Capettini, Nicolò Chiapello
//	Author: Fornero Matteo 

#include "cppheader.hpp"
using namespace std;
extern const char* TAG;

// serialize string content into the buffer
char *serialize_string(char *buffer, string str, unsigned int len)
{
	/* WARNING: the MAC address is fixed in length but SSID is not. Its max size is 32 chars, but we usually use less than 32 so we pad with \0 unused bytes.
				this is necessary because we don't want to include in the buffer sent to the computer a byte indicating the length of the SSID, so we can
				always use the constant BUF_DIM to allocate memory */
	unsigned int i;
	const char *tmp = str.c_str();
	for(i=0; i<str.length(); i++){
		buffer[i]=tmp[i];
	}
	buffer[i]='\0';
	return buffer + len; // alway return a pointer to the first free byte in the buffer
} 

// serialize an unsigned integer into the buffer
char *serialize_uint(unsigned char *buffer, unsigned int value)
{
 	buffer[0] = value >> 24; // note that this approach is platform independent (don't care about hardware specs, endianness etc...)
 	buffer[1] = value >> 16;
  	buffer[2] = value >> 8;
  	buffer[3] = value;
  	return (char*)buffer + 4;
}

// serialize a long long unsigned integer into the buffer
char *serialize_lluint(unsigned char *buffer, uint64_t value)
{
 	buffer[0] = value >> 56; // note that this approach is platform independent (don't care about hardware specs, endianness etc...)
 	buffer[1] = value >> 48;
  	buffer[2] = value >> 40;
  	buffer[3] = value >> 32;
  	buffer[4] = value >> 24;
  	buffer[5] = value >> 16;
  	buffer[6] = value >> 8;
  	buffer[7] = value;
  	return (char*)buffer + 8;
}

uint64_t deserialize_lluint(unsigned char *buffer)
{
	uint64_t value = 0;
	value = buffer[0];
	value = value << 8;
	value += buffer[1];
	value = value << 8;
	value += buffer[2];
	value = value << 8;
	value += buffer[3];
	value = value << 8;
	value += buffer[4];
	value = value << 8;
	value += buffer[5];
	value = value << 8;
	value += buffer[6];
	value = value << 8;
	value += buffer[7];
	return value;
}

// this function handles the serialization of data to be sent to the computer
void serialize_data(packet &it, char *buffer)
{
	char *tmp = buffer;
	tmp = serialize_string(buffer, it.get_MAC(), MAC_DIM);
	tmp = serialize_string(tmp, it.get_SSID(), SSID_DIM);
	tmp[0] = it.get_RSSI(); // rssi is a signed integer on 8 bits so we can simply copy it to the buffer
	tmp++;
	tmp = serialize_lluint((unsigned char*)tmp, it.get_timestamp());
	tmp = serialize_uint((unsigned char*)tmp, it.get_seqnum());
	tmp = serialize_uint((unsigned char*)tmp, it.get_hash());
}

// returns the type of the packet based on the <type> field in the MAC frame header. this is not mandatory for the project but can be useful to add new features
const char *pkt_type_detector(unsigned int type)
{
	switch(type){
		case 0: return "MGMT\0";
		case 1: return "CTRL\0";
		case 2: return "DATA\0";
		case 3: return "RESERVED TYPE\0";
		default: return "INVALID TYPE\0";
	}
}

// returns the subtype of the packet based on the <subtype> field in the MAC frame header. this is not 100% necessary for the project but can be useful to add new features
const char *pkt_subtype_detector(unsigned int type, unsigned int subtype)
{
	switch(type){
		case 0: switch(subtype){
					case 0: return "ASSOCIATION REQUEST\0";
					case 1: return "ASSOCIATION RESPONSE\0";
					case 2: return "REASSOCIATION REQUEST\0";
					case 3: return "REASSOCIATION RESPONSE\0";
					case 4: return "PROBE REQUEST\0";
					case 5: return "PROBE RESPONSE\0";
					case 6: return "reserved subtype\0";
					case 7: return "reserved subtype\0";
					case 8: return "BEACON\0";
					case 9: return "ATIM\0";
					case 10: return "DISASSOCIATION\0";
					case 11: return "AUTHENTICATION\0";
					case 12: return "DEAUTHENTICATION\0";
					case 13: return "ACTION\0";
					case 14: return "reserved subtype\0";
					case 15: return "reserved subtype\0";
					default: return "undefined\0";
				}
		case 1: switch(subtype){
					case 0: return "reserved subtype\0";
					case 1: return "reserved subtype\0";
					case 2: return "reserved subtype\0";
					case 3: return "reserved subtype\0";
					case 4: return "reserved subtype\0";
					case 5: return "reserved subtype\0";
					case 6: return "reserved subtype\0";
					case 7: return "reserved subtype\0";
					case 8: return "BLOCK ACK REQUEST\0";
					case 9: return "BLOCK ACK\0";
					case 10: return "PS-POLL\0";
					case 11: return "RTS\0";
					case 12: return "CTS\0";
					case 13: return "ACK\0";
					case 14: return "CF-END\0";
					case 15: return "CF-END + CF-ACK\0";
					default: return "undefined\0";
				}
		case 2: switch(subtype){
					case 0: return "DATA\0";
					case 1: return "DATA + CF-ACK\0";
					case 2: return "DATA + CF-POLL\0";
					case 3: return "DATA + CF-ACK + CF-POLL\0";
					case 4: return "NULL\0";
					case 5: return "CF-ACK\0";
					case 6: return "CF-POLL\0";
					case 7: return "CF-ACK + CF-POLL\0";
					case 8: return "QoS DATA\0";
					case 9: return "QoS DATA + CF-ACK\0";
					case 10: return "QoS DATA + CF-POLL\0";
					case 11: return "QoS DATA + CF-ACK + CF-POLL\0";
					case 12: return "QoS NULL\0";
					case 13: return "reserved subtype\0";
					case 14: return "QoS(no data) + CF-POLL\0";
					case 15: return "QoS(no data) + CF-ACK\0";
					default: return "undefined\0";
				}
		case 3: return "reserved\0";
		default: return "-\0";
	}
}