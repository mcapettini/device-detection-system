aggiunta:
-concorrenza
-sincronizzazione

da aggiungere:
-aggiustare il bug del 23
-MAC board
-cambiare formato timestamp (deserializzazione) quando si usa il nuovo firware di Matte
-inserimento in BQ (conversione da Packet a Detection)