//	ESP32 Probe Request Analyzer
//	Team members: Matteo Fornero, Fabio Carfì, Marco Capettini, Nicolò Chiapello
//	Author: Fornero Matteo 

// Please see "cheader.h" comments to understand header files organization. 
// This header file must be used only in ".cpp" source code.

#include "cheader.h"
#include <sys/cdefs.h>
#include "sys/time.h"
#include <string>
#include <functional>
#include <unordered_map>
#include <list>
#include <chrono>

/***************************************************************************/

#define BUFDIM 68 // length of data buffer to be sent to the computer
#define MAC_DIM 18 // lenght of the MAC address (xx:xx:xx:xx:xx:xx + space for '\0')
#define SSID_DIM 33 // maximum length of network SSID + space for '\0'
#define MINHEADER 28 // header length for 802.11 (non-HT) frames + 4 bytes for FCS (frame check sequence)
#define MAXHEADER 32 // header length for 802.11 (HT) frames + 4 bytes for FCS (frame check sequence)
#define CHANNELS 13 // this is the number of wifi channels
#define IP_ADDRESS "192.168.1.2" // this is the static ip address of the access point
#define PORT 1500 // this is the default communication port
#define SYNCH_ITER 10 // number of synch packets to be exchanged at each synch time

// each time interval is defined as a number divided by "portTICK_PERIOD_MS"
#define SCAN_INTERVAL 60000 // value (in ms) we wait before turning off sniffer mode and change channel
#define MILLISECONDS 1000 // constant to convert microseconds to seconds 
#define TIME_DIFF 30000 // this is time constant we can use to filter packets more efficiently (see cb_func() comments)
#define CONV2MS(time) (uint64_t)(time/MILLISECONDS) // macro to convert timestamp from microseconds to seconds

/***************************************************************************/

class packet // define a "packet" object that includes all relevant details about the probe request that has been captured
{
	private:
		std::string MAC_address;
		std::string SSID;
		int RSSI;
		uint64_t timestamp;
		unsigned int seq_number;
		unsigned int hash_code;
	public:
		packet();
		packet(std::string address, std::string ssid, int rssi, uint64_t time, unsigned int sequence, unsigned int hashval);
		~packet();
		std::string get_MAC();
		std::string get_SSID();
		uint64_t get_timestamp();
		unsigned int get_seqnum();
		unsigned int get_hash();
		int get_RSSI();
};

/***************************************************************************/

//	802.11 MAC header of probe request packets can be structured in two ways: HT40 (28 bytes) and non-HT40 (24 bytes).
//	non-HT40 is the more common but for reliability is necessary to consider also the HT40 case so I had to define two
//	different data structures which are totally equivalent except for the mac_header_HT40_t that includes one more field
//  (with respect to mac_header_t) called ht_ctrl (its size is 32 bits). So we have also two different type of packet
//	data structure (they are not related to packet class): packet_t and packet_HT40_t.

typedef struct {
	unsigned int version:2;  // 802.11 version (2 bits)
	unsigned int type:2; // type (management, control, data etc...) (2 bits)
	unsigned int subtype:4; // subtype (for example probe req, prob resp etc...) (4 bits)
	uint8_t flags; // 8 bits
	unsigned int duration:16; // 16 bits
	uint8_t dest_addr[6]; // 6 bytes
	uint8_t source_addr[6]; // 6 bytes
	uint8_t bssid[6]; // 6 bytes
	unsigned int seq_ctrl:16; // 16 bits
} mac_header_t;

typedef struct {
	unsigned int version:2;  
	unsigned int type:2; 
	unsigned int subtype:4;
	uint8_t flags;
	unsigned int duration:16; 
	uint8_t dest_addr[6];
	uint8_t source_addr[6];
	uint8_t bssid[6];
	unsigned int seq_ctrl:16;
	uint8_t ht_ctrl[4]; // 4 bytes
} mac_header_HT40_t;

typedef struct {
	uint8_t element_id; // first element in the payload
	uint8_t ssid_len; // second element in the payload
	char ssid[SSID_DIM]; // third element in the payload
} payload_t;

typedef struct {
	mac_header_t header;
	payload_t payload;
} packet_t;

typedef struct {
	mac_header_HT40_t header;
	payload_t payload;
} packet_HT40_t;

/***************************************************************************/

// "core" functions
void tracking(uint8_t);
bool synch();
void send_data();
int make_socket();
void cb_func(void *buffer, wifi_promiscuous_pkt_type_t type); // callback

// functions to serialize packet info before sending through the socket
void serialize_data(packet &, char *buffer);
char *serialize_string(char *buffer, std::string str, unsigned int len);
char *serialize_uint(unsigned char *buffer, unsigned int value);
char *serialize_lluint(unsigned char *buffer, uint64_t value);
uint64_t deserialize_lluint(unsigned char *buffer);

// utilities
const char *pkt_type_detector(unsigned int type);
const char *pkt_subtype_detector(unsigned int type, unsigned int subtype);
unsigned int do_hash(char* buffer, unsigned int pkt_len);