//	ESP32 Probe Request Analyzer
//	Team members: Matteo Fornero, Fabio Carfì, Marco Capettini, Nicolò Chiapello
//	Author: Fornero Matteo 

// Header files organization: since the ESP32 natively supports only the C language but I wanted to use C++ language in order to take advantage
//							  of pre-implemented classes like <list> and <unordered map> I had to create two different headers because
//							  #include <some C++ library> in a header shared also with the main.c would have given problems with the compiler.
//							  This header, in particular, is used in both ".c" and ".cpp" source code. 							  									

#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "esp_wifi.h"
#include "esp_event_loop.h"
#include "freertos/event_groups.h"
#include "freertos/FreeRTOS.h"
#include "nvs_flash.h"
#include "lwip/sockets.h"
#include "esp_log.h"

#define _SSID "AP4ESP32"
#define PASSWORD "11235813"

void mysys_init(); // this function collects several ESP32 APIs to initialize the NVS memory and the WiFi interface 
esp_err_t event_handler(void *ctx, system_event_t *event);