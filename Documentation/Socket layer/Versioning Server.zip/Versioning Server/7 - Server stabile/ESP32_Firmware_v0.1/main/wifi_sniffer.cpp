//	ESP32 Probe Request Analyzer
//	Team members: Matteo Fornero, Fabio Carfì, Marco Capettini, Nicolò Chiapello
//	Author: Fornero Matteo 

#include "cppheader.hpp"
using namespace std;

// for details about the wifi_event_group and the bits see comments in main.c
extern EventGroupHandle_t wifi_event_group;
extern const int CONNECTED_BIT;
extern const int BUSYCONN;

extern const char* TAG; // tag for esp_log_events API
extern char esp_mac[MAC_DIM]; // global because of initialization on main function

unordered_map<string, unsigned int> pkt_map; // unordered map to store source and timestamp of received packets in order to filter them (so we use less memory and we send less data through the network)
list<packet> pkt_list; // list to store data structures containing all important details about received packets
// WARNING: both map and list must be global variables because they must be accessed/modified in the callback function which only allows 2 parameters by design of Espressif

uint8_t channel = 1; // first channel to be scanned
int socketID;
int sockets[3] = {0, 0, 0};
int socknum = 0; // debug only - to be removed

// necessary for C++ compatibility
extern "C" {
	void wifi_sniffer();
}

// these must be global
uint64_t curr_time = 0; // this is the timestamp sent by computer
uint64_t time_origin = 0; // this is the timestamp of the ESP32 when we start the wifi with esp_wifi_start
uint64_t time_stop = 0; // this is the timestamp of the ESP32 when it receives the timestamp from the PC

/* This function handles the real job that has to be done by the ESP32, notice that there is a neverending loop inside it because we want our system
   to be always active. In a real-world scenario this could be a problem if we use batteries to power-up the system, a possible solution could be to use
   the local time (ex. from SNTP server) to determine the moments when the system can be inactive (ex. from 8PM to 7AM in case of a university room), so
   in those moments we yield the resources to a low priority task that does nothing and just waits the right moment to wake up the system (soft of simple
   power saving mode).
*/
void wifi_sniffer()
{
	/*	Timestamp problem: the ESP32 fills the timestamp field as soon as a packet is received but
			the callback is not fired immediately. There is a queue of callbacks so if we receive a packet
			during the callback of another packet we do not loose it. Because of this mechanism we cannot
			exploit the system timer or any other hw/sw timer that we can read or write because there is a
			skew bewteen the moment we receive the packet and the moment we process it in the callback. 
			We must use the embedded hardware timer that is somehow started and stopped with esp_wifi_start()
			and esp_wifi_stop(). Notice also that the field timestamp of the data structure given in the callback
			is 32 bit long and its unit of measure is microseconds so we have overflow every (2^32)-1 which means
			more or less every 71 minutes. The solution adopted here is to call esp_wifi_start and esp_wifi_stop
			every time we must initiate a new loop through the 13 wifi channels, this gives us plenty of margin
			to play around with the timestamp. This is a naive approach, we could also decide to reset the timer
			calling the APIs previously described with an interval of 70 minutes (for example with a dedicated 
			timer or with a counter) but overall this aspect is not so important and does not affect the performance
			of the system. The important things are to keep the timestamp coherent during the sniffing intervals and
			to avoid overflow.
		*/
	
	int counter = 0; // debug only - to be removed
	size_t freeheap = 0; // debug only - to be removed
	int retvalue;
	char buf[4];
	
	ESP_ERROR_CHECK(esp_wifi_set_promiscuous_rx_cb(&cb_func)); // register the callback function
	
	for(;;){ // infinite loop
		freeheap = xPortGetFreeHeapSize(); // debug only - to be removed
		
		if(channel==1){ // do this only at the beginning of each channel loop from 1 to 13
			ESP_ERROR_CHECK(esp_wifi_start()); // start wifi
			time_origin = esp_log_timestamp(); // log the time when we start the wifi (in this precise moment the hw timer for the timestamp has been started)
			xEventGroupSetBits(wifi_event_group, BUSYCONN); // this tells the WIFI_DISCONNECT handler to reconnect in case of disconnection (because we need to stay connected to the AP)
			ESP_ERROR_CHECK(esp_wifi_connect()); // connect to the AP
		}
		
		xEventGroupWaitBits(wifi_event_group, CONNECTED_BIT, pdFALSE, pdTRUE, portMAX_DELAY); // wait forever until connection to the AP is ok
		
		ESP_LOGI(TAG, "starting esp32 synchronization...");		
		while(synch() == false){}; // keep synching until we succeed
		ESP_LOGI(TAG, "esp32 synchronization completed.");
		
		xEventGroupClearBits(wifi_event_group, BUSYCONN); // clear busyconn bit (because now we really want to disconnect from the AP)
		ESP_ERROR_CHECK(esp_wifi_disconnect()); // disconnect from wifi, otherwise packet capture would be done on the channel of the AP
		tracking(channel); // this function handles the packet capture
		
		xEventGroupSetBits(wifi_event_group, BUSYCONN); // in case of disconnection we want to reconnect again as soon as possible
		ESP_ERROR_CHECK(esp_wifi_connect()); // now reconnect to wifi
		xEventGroupWaitBits(wifi_event_group, CONNECTED_BIT, pdFALSE, pdTRUE, portMAX_DELAY); // wait forever until connection (maybe not forever and if not connected we skip everything and jump to new synch?)
		ESP_LOGI(TAG, "starting data transfer to pc...");
		send_data(); // now we send the data to the computer
		ESP_LOGI(TAG, "data transfer completed");
		pkt_list.clear(); // free space used for list
		channel = (channel % CHANNELS) + 1; // go on with next channel
		
		/* this ack is necessary only in case of channel 13 when we must drop down the connection
		   in order to restart the hw timer related to the timestamp. the server is not aware of
		   the channel we are using so we must always adopt the ack mechanism in order to avoid 
		   dropping down the connection (and so the socket) while the server is still reading
		   something from it, this will result in fact in a failure of the read on server's side. */
		memset(buf, '0', 4);
		retvalue = read(socketID, buf, 4);
		if(retvalue!=4 || strncmp(buf, "ACK\0", 4)!=0){
			ESP_LOGE(TAG, "ACK failure after sending data to server.");
		}
		
		if(channel==1){ // in case we need to re-initiate the sniffing loop we disconnect, stop and restart wifi as previously described
			xEventGroupClearBits(wifi_event_group, BUSYCONN); // clear busyconn bit
			ESP_ERROR_CHECK(esp_wifi_disconnect());
			ESP_ERROR_CHECK(esp_wifi_stop()); // this is necessary to restart the hw timer used to compute the timestamp in the callback
		}
		
		ESP_LOGI(TAG, "HEAP MEMORY STATS -> start: %u | end: %u", freeheap, xPortGetFreeHeapSize()); // debug only - to be removed
		ESP_LOGE(TAG, "Counter value is -> %d", counter); // debug only - to be removed
		ESP_LOGE(TAG, "Number of open socket is -> %d", socknum); // debug only - to be removed
		counter++; // debug only - to be removed
	}	
}

// enable sniffer, wait 60 seconds, disable sniffer (in this time interval each probe request packet triggers the callback function)
void tracking(uint8_t channel)
{
	ESP_LOGI(TAG, "starting to monitor probe requests on channel %u...", channel);
	ESP_ERROR_CHECK(esp_wifi_set_channel(channel, WIFI_SECOND_CHAN_NONE)); // set channel to be scanned, do not use a second channel
	ESP_ERROR_CHECK(esp_wifi_set_promiscuous(true)); // set the wifi interface into promiscuous mode
	vTaskDelay(SCAN_INTERVAL / portTICK_PERIOD_MS); 
	ESP_ERROR_CHECK(esp_wifi_set_promiscuous(false)); // disable promiscuous mode
	ESP_LOGI(TAG, "probe request monitoring completed, collected %d packets.", pkt_list.size());
	pkt_map.clear(); // free space used for map because it is no longer needed
}

// callback function for probe request packets
void cb_func(void *buf, wifi_promiscuous_pkt_type_t type)
{
	if(type != WIFI_PKT_MGMT){
		return; // if not a management packet return (should not be necessary if the filter works correctly)
	}

	// collect some informations about the captured packet (automatically given by the callback implementation, no need to look inside the packet at this step)
	const wifi_promiscuous_pkt_t *capt_pkt = (wifi_promiscuous_pkt_t *)buf; // API specific
	int8_t rssi = capt_pkt->rx_ctrl.rssi;
	unsigned int pkt_len = capt_pkt->rx_ctrl.sig_len; // length of packet including Frame Check Sequence (FCS) 
	unsigned int channel = capt_pkt->rx_ctrl.channel;
	unsigned int isHT40 = capt_pkt->rx_ctrl.cwb; // 0: "standard" frame header - 1: "extended" HT frame header
	// WARNING: the following value is given by a hardware timer handled automatically by Espressif's Wifi APIs and there is no way for the developer to read, write,
	// set or reset the timer. The only way to know its value is to read the timestamp field in the callback (BTW the timer is set and reset with esp_wifi_start/stop)
	uint64_t timestamp = (uint64_t)capt_pkt->rx_ctrl.timestamp;
	uint64_t recv_time = curr_time + (CONV2MS(timestamp) - (time_stop - time_origin));  
	/* to obtain a timestamp expressed as milliseconds from epoch we get the epoch time from the computer and we add to it an offset which is equal to the time passed
	from the moment we receive epoch and the moment we set the timestamp in its field (time origin is needed to make these times comparable because it tells us
	how much time has passed from the moment we turned on the ESP32 to the moment we got the epoch time from the computer) */
	
	// the MAC header structure of the captured packet depends on the 802.11 standard that has been used (b/g/n/ac) so we must adopt different strategies
	// to read correctly the informations inside the MAC header and inside the payload (the variable isHT40 is used for this purpose)
	const payload_t *payload = NULL;
	size_t payload_size = 0;
	unsigned int pkt_type = 0;
	unsigned int pkt_subtype = 0;
	unsigned int seq_num = 0;
	char tmp[MAC_DIM]; // temporary buffer to store source MAC address
	string source_mac;
	string ssid;

	// case 1 -> 802.11 non-HT (24 bytes for the header, 0-2312 byte for the frame body, 4 bytes for FCS)
	if(isHT40 == 0){
		const packet_t *packet = (packet_t*)capt_pkt->payload; // packet is a pointer to an area of memory that is treated as a "packet structure"
		payload_size = (size_t)pkt_len - MINHEADER; // this is the effective size of the payload of the captured packet (total size - header - fcs)
		const mac_header_t *header = &packet->header; // this is the MAC header of the captured packet
		pkt_type = header->type; // type of the packet (should be 00 -> management)
		pkt_subtype = header->subtype; // subtype of the packet (should be 0100 -> probe request)
		payload = &packet->payload; // this is the payload of the captuerd packet
		seq_num = header->seq_ctrl;
		sprintf(tmp, "%02x:%02x:%02x:%02x:%02x:%02x", header->source_addr[0], header->source_addr[1], header->source_addr[2], header->source_addr[3], header->source_addr[4], header->source_addr[5]);
		source_mac.assign(tmp);
	}

	// case 2 -> 802.11 HT mode (28 bytes for the header, 0-2312 byte for the frame body, 4 bytes for FCS)
	if(isHT40 == 1){
		const packet_HT40_t *packet = (packet_HT40_t*)capt_pkt->payload; 
		payload_size = (size_t)pkt_len - MAXHEADER; 
		const mac_header_HT40_t *header = &packet->header; 
		pkt_type = header->type; 
		pkt_subtype = header->subtype; 
		payload = &packet->payload;
		seq_num = header->seq_ctrl;
		sprintf(tmp, "%02x:%02x:%02x:%02x:%02x:%02x", header->source_addr[0], header->source_addr[1], header->source_addr[2], header->source_addr[3], header->source_addr[4], header->source_addr[5]);
		source_mac.assign(tmp);
	}

	if(pkt_type!=0 || pkt_subtype!=4){
		return; // at this point we read into the MAC header the type and subtype of the packet. if it is not a probe request packet return.
	}

	// now we can look into the payload to collect the last information we need: the SSID that the device is searching (ssid could be empty, do this only if payload is not empty)
	if( (payload_size > 0) && (payload->ssid_len > 0) ){
		ssid.assign(payload->ssid, payload->ssid_len);
		ssid.append(1, '\0'); // add null terminator
	} else {
		ssid.assign("broadcast\0");
	}

	unordered_map<string, unsigned int>::iterator it = pkt_map.find(source_mac); // check if source MAC is already in the map
	if (it != pkt_map.end() && ((CONV2MS(timestamp) - CONV2MS(it->second)) > TIME_DIFF)) { // MAC already in map and previous packet registered more than TIME_DIFF seconds ago
		it->second = timestamp; // update timestamp in map at key = source MAC
		string tohash;
		char tmp2[20];
		memset(tmp2, '0', 20);
		tohash.assign(source_mac);
		tohash.append(ssid);
		tohash.append(itoa(seq_num, tmp2, 10));
		char *buf = (char*)tohash.c_str();
		unsigned int hashval = do_hash(buf, (unsigned int)tohash.size()); // compute hash of packet
		packet pkt(source_mac, ssid, rssi, recv_time, seq_num, hashval); // create packet object 
		pkt_list.push_back(pkt); // insert packet into list of packets to be sent to the computer
		ESP_LOGI(TAG, "Source: %s | SSID: %s | Timestamp: %llu | Channel: %u | RSSI: %d | Seq.Numb: %u | Hash: %u", source_mac.c_str(), ssid.c_str(), recv_time, channel, rssi, seq_num, hashval);
	}
	if (it == pkt_map.end()) { // new MAC source address
		pair<string, unsigned int> element(source_mac, timestamp); // pair object that contains key and value for the map
		pkt_map.insert(element); // insert element into map
		string tohash;
		char tmp2[20];
		memset(tmp2, '0', 20);
		tohash.assign(source_mac);
		tohash.append(ssid);
		tohash.append(itoa(seq_num, tmp2, 10));
		char *buf = (char*)tohash.c_str();
		unsigned int hashval = do_hash(buf, (unsigned int)tohash.size()); // compute hash of packet
		packet pkt(source_mac, ssid, rssi, recv_time, seq_num, hashval);
		pkt_list.push_back(pkt);
		ESP_LOGI(TAG, "Source: %s | SSID: %s | Timestamp: %llu | Channel: %u | RSSI: %d | Seq.Numb: %u | Hash: %u", source_mac.c_str(), ssid.c_str(), recv_time, channel, rssi, seq_num, hashval);
	}
}

// this function simply establish a socket and a connection with the computer
int make_socket()
{
	struct sockaddr_in pc_addr;
	pc_addr.sin_family = AF_INET;
	pc_addr.sin_port = htons(PORT);
	int res = inet_pton(AF_INET, IP_ADDRESS, &(pc_addr.sin_addr)); // use inet_pton to grant IPv6 compatibility
	if(res <= 0){
		return -1;
	}
	int s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if(s < 0){
		return -1;
	}
	if(connect(s, (struct sockaddr*) &pc_addr, sizeof(pc_addr)) != 0){
		close(s);
		return -1;
	}
	
	/* this is a window mechanism to close sockets only a few minutes after they have been closed on the other end.
	   this allows us to avoid waiting for an ack signal from the server to know if it has processed all the data
	   and we can close the socket. with a value of the window of 3 we normally close a socket 2 minutes after 
	   we sent all the data so is reasonable to suppose that the computer does not need that socket anymore. */
	if(sockets[0]>0){
		close(sockets[0]);
		socknum--;
	}
	sockets[0] = sockets[1];
	sockets[1] = sockets[2];
	sockets[2] = s;
	socknum++;
	return s;
}

// this function sends collected data to the access point
void send_data()
{
	socketID = make_socket();
	if(socketID < 0){
		return;
	}
	ssize_t retvalue = 0; // to check the return value of send, write, read and recv
	uint32_t dim = pkt_list.size(); // number of packets collected by the ESP32 (with basic filters already applied)
	unsigned char pkt_num[4]; // we need 4 bytes because the number of packets is on 32 bit
	memset(pkt_num, '0', 4);
	serialize_uint(pkt_num, dim); // data serialization for transmission over socket
	retvalue = write(socketID, pkt_num, 4); // send total number of packets that are going to be sent
	if(retvalue != 4){
		return;
	}
	
	// now iterate through the list and send a packet for each element into the list (we pay a lot of overhead but we reduce risks of losing data during the transmission)
	for (list<packet>::iterator it = pkt_list.begin(); it != pkt_list.end(); it++) {
		char *buffer = NULL;
		buffer = (char*)malloc(BUFDIM);
		if(buffer==NULL){
			return;
		}
		memset(buffer, 0, BUFDIM); // clear the buffer
		serialize_data(*it, buffer); // put data inside the buffer
		ssize_t res = write(socketID, buffer, BUFDIM);
		free(buffer);
		if(res != BUFDIM){
			return;
		}
	} 
}

// this function performs the synchronization between a single ESP32 board and the PC used to collect and store data
bool synch()
{
	unsigned int i = 0;
	ssize_t retvalue = 0;
	char buffer[10];
	memset(buffer, '0', 10);
	
	// send a bunch of data on the socket (code +205ALIVE) to check if it is still alive
	bool sock_alive = false;
	if(channel != 1){
		retvalue = write(socketID, "ALIVE\0", 6);
		if(retvalue==6){
			retvalue = read(socketID, buffer, 6);
			if((retvalue==6) && (strncmp(buffer, "ALIVE\0", 6)==0)){
				sock_alive = true;
				ESP_LOGI(TAG, "synch() - found valid old socket");
			}
		}
	}
	
	if(channel==1 || sock_alive==false){ // if channel is 1 we need to open a new socket (because previously we were disconnected from the AP)
		socketID = make_socket();
		if(socketID < 0){
			return false;
		}
		ESP_LOGI(TAG, "synch() - new socket necessary");
	}	

	// now exchange synch packets with pc to estimate wireless signal propagation time to esp32 and back to pc
	i = 0;
	memset(buffer, '0', 10);
	while(i<SYNCH_ITER){
		retvalue = read(socketID, buffer, 7);
		if((retvalue != 7) || (strncmp(buffer, "SYNREQ\0", 7)!=0)){
			return false;
		}
		retvalue = write(socketID, "SYNACK\0", 7);
		if(retvalue != 7){
			return false;
		}
		i++;
	}

	// now read the actual PC time and save it in curr_time (needs to be converted from char* to int)
	curr_time = 0;
	memset(buffer, '0', 8);
	retvalue = read(socketID, buffer, 8); 
	if(retvalue != 8){
			return false;
	}
	time_stop = esp_log_timestamp();
	curr_time = deserialize_lluint((unsigned char*)buffer);
	
	// send ESP32's MAC to computer
	retvalue = write(socketID, esp_mac, MAC_DIM);
	if(retvalue != MAC_DIM){
			return false;
	}

	// now wait for the GO signal
	bool go = false; 
	do{
		retvalue = read(socketID, buffer, 3);
		if(retvalue < 0){
			return false;
		}
		if(strncmp(buffer, "GO\0", 3) == 0){
			go = true;
		}
	} while(go == false);
	// no need to close the socket because closing it will be done in the make_socket function thanks to the window mechanism
	return true;
}