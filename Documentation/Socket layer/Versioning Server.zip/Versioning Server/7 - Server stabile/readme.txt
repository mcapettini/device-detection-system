IMPORTANTE:
ricordarsi di cambiare parametro dimensione finestra TCP lwIP SND_BUF = 11488 o pi�

aggiunto:
� cambiata molto la struttra del codice (sono stati spostate parti, ampliate alcune altre),
in particolare sono stati gestiti tutti gli errori critici in modo tale da garantire robustezza

da aggiungere:
guardare versione 7A per trasformare il codice